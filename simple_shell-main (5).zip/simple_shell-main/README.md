Simple Shell project 0x16.c - GIGBAMSsh -This is a simple UNIX command interpreter based on bash and Sh.
